﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class consoleapp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(consoleapp))
        Me.GunaLabel1 = New Guna.UI.WinForms.GunaLabel()
        Me.GunaControlBox2 = New Guna.UI.WinForms.GunaControlBox()
        Me.GunaControlBox1 = New Guna.UI.WinForms.GunaControlBox()
        Me.GunaPanel1 = New Guna.UI.WinForms.GunaPanel()
        Me.GunaElipse1 = New Guna.UI.WinForms.GunaElipse(Me.components)
        Me.Guna2ShadowForm1 = New Guna.UI2.WinForms.Guna2ShadowForm(Me.components)
        Me.Guna2DragControl1 = New Guna.UI2.WinForms.Guna2DragControl(Me.components)
        Me.Guna2DragControl2 = New Guna.UI2.WinForms.Guna2DragControl(Me.components)
        Me.Guna2DragControl3 = New Guna.UI2.WinForms.Guna2DragControl(Me.components)
        Me.Guna2Button2 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button1 = New Guna.UI2.WinForms.Guna2Button()
        Me.GunaPictureBox1 = New Guna.UI.WinForms.GunaPictureBox()
        Me.syntax1 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt1 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.syntax2 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt2 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.syntax3 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt3 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.syntax4 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt4 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.syntax5 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt5 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.syntax6 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt6 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.syntax7 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt7 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.syntax8 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.text8 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.syntax9 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt9 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.syntax10 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt10 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.syntax11 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt11 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.syntax12 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt12 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.GunaPanel1.SuspendLayout()
        CType(Me.GunaPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GunaLabel1
        '
        Me.GunaLabel1.AutoSize = True
        Me.GunaLabel1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaLabel1.ForeColor = System.Drawing.Color.Silver
        Me.GunaLabel1.Location = New System.Drawing.Point(40, 9)
        Me.GunaLabel1.Name = "GunaLabel1"
        Me.GunaLabel1.Size = New System.Drawing.Size(126, 15)
        Me.GunaLabel1.TabIndex = 1
        Me.GunaLabel1.Text = "Console App - Poficol "
        Me.GunaLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GunaControlBox2
        '
        Me.GunaControlBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaControlBox2.AnimationHoverSpeed = 0.07!
        Me.GunaControlBox2.AnimationSpeed = 0.03!
        Me.GunaControlBox2.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.GunaControlBox2.IconColor = System.Drawing.Color.White
        Me.GunaControlBox2.IconSize = 15.0!
        Me.GunaControlBox2.Location = New System.Drawing.Point(1068, -2)
        Me.GunaControlBox2.Name = "GunaControlBox2"
        Me.GunaControlBox2.OnHoverBackColor = System.Drawing.Color.Navy
        Me.GunaControlBox2.OnHoverIconColor = System.Drawing.Color.White
        Me.GunaControlBox2.OnPressedColor = System.Drawing.Color.Black
        Me.GunaControlBox2.Size = New System.Drawing.Size(45, 36)
        Me.GunaControlBox2.TabIndex = 0
        '
        'GunaControlBox1
        '
        Me.GunaControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaControlBox1.AnimationHoverSpeed = 0.07!
        Me.GunaControlBox1.AnimationSpeed = 0.03!
        Me.GunaControlBox1.ControlBoxType = Guna.UI.WinForms.FormControlBoxType.MinimizeBox
        Me.GunaControlBox1.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.GunaControlBox1.IconColor = System.Drawing.Color.White
        Me.GunaControlBox1.IconSize = 15.0!
        Me.GunaControlBox1.Location = New System.Drawing.Point(1027, -2)
        Me.GunaControlBox1.Name = "GunaControlBox1"
        Me.GunaControlBox1.OnHoverBackColor = System.Drawing.Color.Navy
        Me.GunaControlBox1.OnHoverIconColor = System.Drawing.Color.White
        Me.GunaControlBox1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaControlBox1.Size = New System.Drawing.Size(40, 36)
        Me.GunaControlBox1.TabIndex = 0
        '
        'GunaPanel1
        '
        Me.GunaPanel1.BackColor = System.Drawing.Color.Black
        Me.GunaPanel1.Controls.Add(Me.GunaLabel1)
        Me.GunaPanel1.Controls.Add(Me.GunaPictureBox1)
        Me.GunaPanel1.Controls.Add(Me.GunaControlBox2)
        Me.GunaPanel1.Controls.Add(Me.GunaControlBox1)
        Me.GunaPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GunaPanel1.Location = New System.Drawing.Point(0, 0)
        Me.GunaPanel1.Name = "GunaPanel1"
        Me.GunaPanel1.Size = New System.Drawing.Size(1114, 34)
        Me.GunaPanel1.TabIndex = 3
        '
        'GunaElipse1
        '
        Me.GunaElipse1.Radius = 5
        Me.GunaElipse1.TargetControl = Me
        '
        'Guna2ShadowForm1
        '
        Me.Guna2ShadowForm1.BorderRadius = 100
        Me.Guna2ShadowForm1.TargetForm = Me
        '
        'Guna2DragControl1
        '
        Me.Guna2DragControl1.DockIndicatorColor = System.Drawing.Color.Silver
        Me.Guna2DragControl1.TargetControl = Me.GunaPanel1
        Me.Guna2DragControl1.TransparentWhileDrag = True
        Me.Guna2DragControl1.UseTransparentDrag = True
        '
        'Guna2DragControl2
        '
        Me.Guna2DragControl2.DockIndicatorColor = System.Drawing.Color.Silver
        Me.Guna2DragControl2.DockIndicatorTransparencyValue = 0.7R
        Me.Guna2DragControl2.TargetControl = Me.GunaPictureBox1
        Me.Guna2DragControl2.TransparentWhileDrag = True
        Me.Guna2DragControl2.UseTransparentDrag = True
        '
        'Guna2DragControl3
        '
        Me.Guna2DragControl3.DockIndicatorColor = System.Drawing.Color.Silver
        Me.Guna2DragControl3.TargetControl = Me.GunaLabel1
        Me.Guna2DragControl3.TransparentWhileDrag = True
        Me.Guna2DragControl3.UseTransparentDrag = True
        '
        'Guna2Button2
        '
        Me.Guna2Button2.BorderColor = System.Drawing.Color.Transparent
        Me.Guna2Button2.BorderRadius = 10
        Me.Guna2Button2.CheckedState.Parent = Me.Guna2Button2
        Me.Guna2Button2.CustomImages.Parent = Me.Guna2Button2
        Me.Guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2Button2.DisabledState.Parent = Me.Guna2Button2
        Me.Guna2Button2.FillColor = System.Drawing.Color.Black
        Me.Guna2Button2.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2Button2.ForeColor = System.Drawing.Color.White
        Me.Guna2Button2.HoverState.Parent = Me.Guna2Button2
        Me.Guna2Button2.Image = Global.Poficol.My.Resources.Resources._stop
        Me.Guna2Button2.ImageSize = New System.Drawing.Size(29, 29)
        Me.Guna2Button2.Location = New System.Drawing.Point(103, 40)
        Me.Guna2Button2.Name = "Guna2Button2"
        Me.Guna2Button2.PressedColor = System.Drawing.Color.DimGray
        Me.Guna2Button2.ShadowDecoration.Parent = Me.Guna2Button2
        Me.Guna2Button2.Size = New System.Drawing.Size(90, 33)
        Me.Guna2Button2.TabIndex = 5
        Me.Guna2Button2.Text = "Stop"
        '
        'Guna2Button1
        '
        Me.Guna2Button1.BorderColor = System.Drawing.Color.Transparent
        Me.Guna2Button1.BorderRadius = 10
        Me.Guna2Button1.CheckedState.Parent = Me.Guna2Button1
        Me.Guna2Button1.CustomImages.Parent = Me.Guna2Button1
        Me.Guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2Button1.DisabledState.Parent = Me.Guna2Button1
        Me.Guna2Button1.FillColor = System.Drawing.Color.Black
        Me.Guna2Button1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button1.ForeColor = System.Drawing.Color.White
        Me.Guna2Button1.HoverState.Parent = Me.Guna2Button1
        Me.Guna2Button1.Image = Global.Poficol.My.Resources.Resources.run
        Me.Guna2Button1.ImageSize = New System.Drawing.Size(29, 29)
        Me.Guna2Button1.Location = New System.Drawing.Point(6, 40)
        Me.Guna2Button1.Name = "Guna2Button1"
        Me.Guna2Button1.PressedColor = System.Drawing.Color.DimGray
        Me.Guna2Button1.ShadowDecoration.Parent = Me.Guna2Button1
        Me.Guna2Button1.Size = New System.Drawing.Size(91, 33)
        Me.Guna2Button1.TabIndex = 5
        Me.Guna2Button1.Text = "Run.."
        '
        'GunaPictureBox1
        '
        Me.GunaPictureBox1.BackColor = System.Drawing.Color.Black
        Me.GunaPictureBox1.BaseColor = System.Drawing.Color.White
        Me.GunaPictureBox1.Image = Global.Poficol.My.Resources.Resources.icon
        Me.GunaPictureBox1.Location = New System.Drawing.Point(6, 2)
        Me.GunaPictureBox1.Name = "GunaPictureBox1"
        Me.GunaPictureBox1.Size = New System.Drawing.Size(30, 28)
        Me.GunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.GunaPictureBox1.TabIndex = 4
        Me.GunaPictureBox1.TabStop = False
        '
        'syntax1
        '
        Me.syntax1.Animated = True
        Me.syntax1.AutoCompleteCustomSource.AddRange(New String() {"txtaskconsole::", "openontext::", "webshow,render", "txtMsgAsk", "widLoadAskmsgweb"})
        Me.syntax1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.syntax1.BorderColor = System.Drawing.Color.Black
        Me.syntax1.BorderRadius = 10
        Me.syntax1.BorderThickness = 0
        Me.syntax1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.syntax1.DefaultText = ""
        Me.syntax1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.syntax1.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.syntax1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax1.DisabledState.Parent = Me.syntax1
        Me.syntax1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax1.FillColor = System.Drawing.Color.Black
        Me.syntax1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax1.FocusedState.Parent = Me.syntax1
        Me.syntax1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.syntax1.ForeColor = System.Drawing.Color.White
        Me.syntax1.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax1.HoverState.Parent = Me.syntax1
        Me.syntax1.Location = New System.Drawing.Point(12, 79)
        Me.syntax1.Name = "syntax1"
        Me.syntax1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.syntax1.PlaceholderForeColor = System.Drawing.Color.Black
        Me.syntax1.PlaceholderText = ""
        Me.syntax1.SelectedText = ""
        Me.syntax1.ShadowDecoration.Parent = Me.syntax1
        Me.syntax1.Size = New System.Drawing.Size(603, 36)
        Me.syntax1.TabIndex = 6
        '
        'txt1
        '
        Me.txt1.Animated = True
        Me.txt1.BorderColor = System.Drawing.Color.Black
        Me.txt1.BorderRadius = 10
        Me.txt1.BorderThickness = 0
        Me.txt1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt1.DefaultText = ""
        Me.txt1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt1.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt1.DisabledState.Parent = Me.txt1
        Me.txt1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt1.FillColor = System.Drawing.Color.Black
        Me.txt1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt1.FocusedState.Parent = Me.txt1
        Me.txt1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt1.ForeColor = System.Drawing.Color.White
        Me.txt1.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt1.HoverState.Parent = Me.txt1
        Me.txt1.Location = New System.Drawing.Point(621, 79)
        Me.txt1.Name = "txt1"
        Me.txt1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt1.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txt1.PlaceholderText = ""
        Me.txt1.SelectedText = ""
        Me.txt1.ShadowDecoration.Parent = Me.txt1
        Me.txt1.Size = New System.Drawing.Size(469, 36)
        Me.txt1.TabIndex = 6
        '
        'syntax2
        '
        Me.syntax2.Animated = True
        Me.syntax2.AutoCompleteCustomSource.AddRange(New String() {"txtaskconsole::", "openontext::", "webshow,render", "txtMsgAsk", "widLoadAskmsgweb"})
        Me.syntax2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.syntax2.BorderColor = System.Drawing.Color.Black
        Me.syntax2.BorderRadius = 10
        Me.syntax2.BorderThickness = 0
        Me.syntax2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.syntax2.DefaultText = ""
        Me.syntax2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.syntax2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.syntax2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax2.DisabledState.Parent = Me.syntax2
        Me.syntax2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax2.FillColor = System.Drawing.Color.Black
        Me.syntax2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax2.FocusedState.Parent = Me.syntax2
        Me.syntax2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.syntax2.ForeColor = System.Drawing.Color.White
        Me.syntax2.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax2.HoverState.Parent = Me.syntax2
        Me.syntax2.Location = New System.Drawing.Point(12, 121)
        Me.syntax2.Name = "syntax2"
        Me.syntax2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.syntax2.PlaceholderForeColor = System.Drawing.Color.Black
        Me.syntax2.PlaceholderText = ""
        Me.syntax2.SelectedText = ""
        Me.syntax2.ShadowDecoration.Parent = Me.syntax2
        Me.syntax2.Size = New System.Drawing.Size(603, 36)
        Me.syntax2.TabIndex = 6
        '
        'txt2
        '
        Me.txt2.Animated = True
        Me.txt2.BorderColor = System.Drawing.Color.Black
        Me.txt2.BorderRadius = 10
        Me.txt2.BorderThickness = 0
        Me.txt2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt2.DefaultText = ""
        Me.txt2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt2.DisabledState.Parent = Me.txt2
        Me.txt2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt2.FillColor = System.Drawing.Color.Black
        Me.txt2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt2.FocusedState.Parent = Me.txt2
        Me.txt2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt2.ForeColor = System.Drawing.Color.White
        Me.txt2.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt2.HoverState.Parent = Me.txt2
        Me.txt2.Location = New System.Drawing.Point(621, 121)
        Me.txt2.Name = "txt2"
        Me.txt2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt2.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txt2.PlaceholderText = ""
        Me.txt2.SelectedText = ""
        Me.txt2.ShadowDecoration.Parent = Me.txt2
        Me.txt2.Size = New System.Drawing.Size(469, 36)
        Me.txt2.TabIndex = 6
        '
        'syntax3
        '
        Me.syntax3.Animated = True
        Me.syntax3.AutoCompleteCustomSource.AddRange(New String() {"txtaskconsole::", "openontext::", "webshow,render", "txtMsgAsk", "widLoadAskmsgweb"})
        Me.syntax3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.syntax3.BorderColor = System.Drawing.Color.Black
        Me.syntax3.BorderRadius = 10
        Me.syntax3.BorderThickness = 0
        Me.syntax3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.syntax3.DefaultText = ""
        Me.syntax3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.syntax3.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.syntax3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax3.DisabledState.Parent = Me.syntax3
        Me.syntax3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax3.FillColor = System.Drawing.Color.Black
        Me.syntax3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax3.FocusedState.Parent = Me.syntax3
        Me.syntax3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.syntax3.ForeColor = System.Drawing.Color.White
        Me.syntax3.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax3.HoverState.Parent = Me.syntax3
        Me.syntax3.Location = New System.Drawing.Point(12, 163)
        Me.syntax3.Name = "syntax3"
        Me.syntax3.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.syntax3.PlaceholderForeColor = System.Drawing.Color.Black
        Me.syntax3.PlaceholderText = ""
        Me.syntax3.SelectedText = ""
        Me.syntax3.ShadowDecoration.Parent = Me.syntax3
        Me.syntax3.Size = New System.Drawing.Size(603, 36)
        Me.syntax3.TabIndex = 6
        '
        'txt3
        '
        Me.txt3.Animated = True
        Me.txt3.BorderColor = System.Drawing.Color.Black
        Me.txt3.BorderRadius = 10
        Me.txt3.BorderThickness = 0
        Me.txt3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt3.DefaultText = ""
        Me.txt3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt3.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt3.DisabledState.Parent = Me.txt3
        Me.txt3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt3.FillColor = System.Drawing.Color.Black
        Me.txt3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt3.FocusedState.Parent = Me.txt3
        Me.txt3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt3.ForeColor = System.Drawing.Color.White
        Me.txt3.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt3.HoverState.Parent = Me.txt3
        Me.txt3.Location = New System.Drawing.Point(621, 163)
        Me.txt3.Name = "txt3"
        Me.txt3.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt3.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txt3.PlaceholderText = ""
        Me.txt3.SelectedText = ""
        Me.txt3.ShadowDecoration.Parent = Me.txt3
        Me.txt3.Size = New System.Drawing.Size(469, 36)
        Me.txt3.TabIndex = 6
        '
        'syntax4
        '
        Me.syntax4.Animated = True
        Me.syntax4.AutoCompleteCustomSource.AddRange(New String() {"txtaskconsole::", "openontext::", "webshow,render", "txtMsgAsk", "widLoadAskmsgweb"})
        Me.syntax4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.syntax4.BorderColor = System.Drawing.Color.Black
        Me.syntax4.BorderRadius = 10
        Me.syntax4.BorderThickness = 0
        Me.syntax4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.syntax4.DefaultText = ""
        Me.syntax4.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.syntax4.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.syntax4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax4.DisabledState.Parent = Me.syntax4
        Me.syntax4.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax4.FillColor = System.Drawing.Color.Black
        Me.syntax4.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax4.FocusedState.Parent = Me.syntax4
        Me.syntax4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.syntax4.ForeColor = System.Drawing.Color.White
        Me.syntax4.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax4.HoverState.Parent = Me.syntax4
        Me.syntax4.Location = New System.Drawing.Point(12, 205)
        Me.syntax4.Name = "syntax4"
        Me.syntax4.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.syntax4.PlaceholderForeColor = System.Drawing.Color.Black
        Me.syntax4.PlaceholderText = ""
        Me.syntax4.SelectedText = ""
        Me.syntax4.ShadowDecoration.Parent = Me.syntax4
        Me.syntax4.Size = New System.Drawing.Size(603, 36)
        Me.syntax4.TabIndex = 6
        '
        'txt4
        '
        Me.txt4.Animated = True
        Me.txt4.BorderColor = System.Drawing.Color.Black
        Me.txt4.BorderRadius = 10
        Me.txt4.BorderThickness = 0
        Me.txt4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt4.DefaultText = ""
        Me.txt4.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt4.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt4.DisabledState.Parent = Me.txt4
        Me.txt4.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt4.FillColor = System.Drawing.Color.Black
        Me.txt4.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt4.FocusedState.Parent = Me.txt4
        Me.txt4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt4.ForeColor = System.Drawing.Color.White
        Me.txt4.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt4.HoverState.Parent = Me.txt4
        Me.txt4.Location = New System.Drawing.Point(621, 205)
        Me.txt4.Name = "txt4"
        Me.txt4.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt4.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txt4.PlaceholderText = ""
        Me.txt4.SelectedText = ""
        Me.txt4.ShadowDecoration.Parent = Me.txt4
        Me.txt4.Size = New System.Drawing.Size(469, 36)
        Me.txt4.TabIndex = 6
        '
        'syntax5
        '
        Me.syntax5.Animated = True
        Me.syntax5.AutoCompleteCustomSource.AddRange(New String() {"txtaskconsole::", "openontext::", "webshow,render", "txtMsgAsk", "widLoadAskmsgweb"})
        Me.syntax5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.syntax5.BorderColor = System.Drawing.Color.Black
        Me.syntax5.BorderRadius = 10
        Me.syntax5.BorderThickness = 0
        Me.syntax5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.syntax5.DefaultText = ""
        Me.syntax5.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.syntax5.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.syntax5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax5.DisabledState.Parent = Me.syntax5
        Me.syntax5.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax5.FillColor = System.Drawing.Color.Black
        Me.syntax5.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax5.FocusedState.Parent = Me.syntax5
        Me.syntax5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.syntax5.ForeColor = System.Drawing.Color.White
        Me.syntax5.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax5.HoverState.Parent = Me.syntax5
        Me.syntax5.Location = New System.Drawing.Point(12, 247)
        Me.syntax5.Name = "syntax5"
        Me.syntax5.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.syntax5.PlaceholderForeColor = System.Drawing.Color.Black
        Me.syntax5.PlaceholderText = ""
        Me.syntax5.SelectedText = ""
        Me.syntax5.ShadowDecoration.Parent = Me.syntax5
        Me.syntax5.Size = New System.Drawing.Size(603, 36)
        Me.syntax5.TabIndex = 6
        '
        'txt5
        '
        Me.txt5.Animated = True
        Me.txt5.BorderColor = System.Drawing.Color.Black
        Me.txt5.BorderRadius = 10
        Me.txt5.BorderThickness = 0
        Me.txt5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt5.DefaultText = ""
        Me.txt5.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt5.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt5.DisabledState.Parent = Me.txt5
        Me.txt5.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt5.FillColor = System.Drawing.Color.Black
        Me.txt5.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt5.FocusedState.Parent = Me.txt5
        Me.txt5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt5.ForeColor = System.Drawing.Color.White
        Me.txt5.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt5.HoverState.Parent = Me.txt5
        Me.txt5.Location = New System.Drawing.Point(621, 247)
        Me.txt5.Name = "txt5"
        Me.txt5.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt5.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txt5.PlaceholderText = ""
        Me.txt5.SelectedText = ""
        Me.txt5.ShadowDecoration.Parent = Me.txt5
        Me.txt5.Size = New System.Drawing.Size(469, 36)
        Me.txt5.TabIndex = 6
        '
        'syntax6
        '
        Me.syntax6.Animated = True
        Me.syntax6.AutoCompleteCustomSource.AddRange(New String() {"txtaskconsole::", "openontext::", "webshow,render", "txtMsgAsk", "widLoadAskmsgweb"})
        Me.syntax6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.syntax6.BorderColor = System.Drawing.Color.Black
        Me.syntax6.BorderRadius = 10
        Me.syntax6.BorderThickness = 0
        Me.syntax6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.syntax6.DefaultText = ""
        Me.syntax6.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.syntax6.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.syntax6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax6.DisabledState.Parent = Me.syntax6
        Me.syntax6.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax6.FillColor = System.Drawing.Color.Black
        Me.syntax6.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax6.FocusedState.Parent = Me.syntax6
        Me.syntax6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.syntax6.ForeColor = System.Drawing.Color.White
        Me.syntax6.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax6.HoverState.Parent = Me.syntax6
        Me.syntax6.Location = New System.Drawing.Point(12, 289)
        Me.syntax6.Name = "syntax6"
        Me.syntax6.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.syntax6.PlaceholderForeColor = System.Drawing.Color.Black
        Me.syntax6.PlaceholderText = ""
        Me.syntax6.SelectedText = ""
        Me.syntax6.ShadowDecoration.Parent = Me.syntax6
        Me.syntax6.Size = New System.Drawing.Size(603, 36)
        Me.syntax6.TabIndex = 6
        '
        'txt6
        '
        Me.txt6.Animated = True
        Me.txt6.BorderColor = System.Drawing.Color.Black
        Me.txt6.BorderRadius = 10
        Me.txt6.BorderThickness = 0
        Me.txt6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt6.DefaultText = ""
        Me.txt6.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt6.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt6.DisabledState.Parent = Me.txt6
        Me.txt6.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt6.FillColor = System.Drawing.Color.Black
        Me.txt6.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt6.FocusedState.Parent = Me.txt6
        Me.txt6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt6.ForeColor = System.Drawing.Color.White
        Me.txt6.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt6.HoverState.Parent = Me.txt6
        Me.txt6.Location = New System.Drawing.Point(621, 289)
        Me.txt6.Name = "txt6"
        Me.txt6.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt6.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txt6.PlaceholderText = ""
        Me.txt6.SelectedText = ""
        Me.txt6.ShadowDecoration.Parent = Me.txt6
        Me.txt6.Size = New System.Drawing.Size(469, 36)
        Me.txt6.TabIndex = 6
        '
        'syntax7
        '
        Me.syntax7.Animated = True
        Me.syntax7.AutoCompleteCustomSource.AddRange(New String() {"txtaskconsole::", "openontext::", "webshow,render", "txtMsgAsk", "widLoadAskmsgweb"})
        Me.syntax7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.syntax7.BorderColor = System.Drawing.Color.Black
        Me.syntax7.BorderRadius = 10
        Me.syntax7.BorderThickness = 0
        Me.syntax7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.syntax7.DefaultText = ""
        Me.syntax7.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.syntax7.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.syntax7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax7.DisabledState.Parent = Me.syntax7
        Me.syntax7.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax7.FillColor = System.Drawing.Color.Black
        Me.syntax7.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax7.FocusedState.Parent = Me.syntax7
        Me.syntax7.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.syntax7.ForeColor = System.Drawing.Color.White
        Me.syntax7.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax7.HoverState.Parent = Me.syntax7
        Me.syntax7.Location = New System.Drawing.Point(12, 331)
        Me.syntax7.Name = "syntax7"
        Me.syntax7.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.syntax7.PlaceholderForeColor = System.Drawing.Color.Black
        Me.syntax7.PlaceholderText = ""
        Me.syntax7.SelectedText = ""
        Me.syntax7.ShadowDecoration.Parent = Me.syntax7
        Me.syntax7.Size = New System.Drawing.Size(603, 36)
        Me.syntax7.TabIndex = 6
        '
        'txt7
        '
        Me.txt7.Animated = True
        Me.txt7.BorderColor = System.Drawing.Color.Black
        Me.txt7.BorderRadius = 10
        Me.txt7.BorderThickness = 0
        Me.txt7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt7.DefaultText = ""
        Me.txt7.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt7.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt7.DisabledState.Parent = Me.txt7
        Me.txt7.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt7.FillColor = System.Drawing.Color.Black
        Me.txt7.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt7.FocusedState.Parent = Me.txt7
        Me.txt7.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt7.ForeColor = System.Drawing.Color.White
        Me.txt7.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt7.HoverState.Parent = Me.txt7
        Me.txt7.Location = New System.Drawing.Point(621, 331)
        Me.txt7.Name = "txt7"
        Me.txt7.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt7.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txt7.PlaceholderText = ""
        Me.txt7.SelectedText = ""
        Me.txt7.ShadowDecoration.Parent = Me.txt7
        Me.txt7.Size = New System.Drawing.Size(469, 36)
        Me.txt7.TabIndex = 6
        '
        'syntax8
        '
        Me.syntax8.Animated = True
        Me.syntax8.AutoCompleteCustomSource.AddRange(New String() {"txtaskconsole::", "openontext::", "webshow,render", "txtMsgAsk", "widLoadAskmsgweb"})
        Me.syntax8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.syntax8.BorderColor = System.Drawing.Color.Black
        Me.syntax8.BorderRadius = 10
        Me.syntax8.BorderThickness = 0
        Me.syntax8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.syntax8.DefaultText = ""
        Me.syntax8.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.syntax8.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.syntax8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax8.DisabledState.Parent = Me.syntax8
        Me.syntax8.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax8.FillColor = System.Drawing.Color.Black
        Me.syntax8.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax8.FocusedState.Parent = Me.syntax8
        Me.syntax8.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.syntax8.ForeColor = System.Drawing.Color.White
        Me.syntax8.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax8.HoverState.Parent = Me.syntax8
        Me.syntax8.Location = New System.Drawing.Point(12, 373)
        Me.syntax8.Name = "syntax8"
        Me.syntax8.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.syntax8.PlaceholderForeColor = System.Drawing.Color.Black
        Me.syntax8.PlaceholderText = ""
        Me.syntax8.SelectedText = ""
        Me.syntax8.ShadowDecoration.Parent = Me.syntax8
        Me.syntax8.Size = New System.Drawing.Size(603, 36)
        Me.syntax8.TabIndex = 6
        '
        'text8
        '
        Me.text8.Animated = True
        Me.text8.BorderColor = System.Drawing.Color.Black
        Me.text8.BorderRadius = 10
        Me.text8.BorderThickness = 0
        Me.text8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.text8.DefaultText = ""
        Me.text8.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.text8.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.text8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.text8.DisabledState.Parent = Me.text8
        Me.text8.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.text8.FillColor = System.Drawing.Color.Black
        Me.text8.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.text8.FocusedState.Parent = Me.text8
        Me.text8.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.text8.ForeColor = System.Drawing.Color.White
        Me.text8.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.text8.HoverState.Parent = Me.text8
        Me.text8.Location = New System.Drawing.Point(621, 373)
        Me.text8.Name = "text8"
        Me.text8.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.text8.PlaceholderForeColor = System.Drawing.Color.Black
        Me.text8.PlaceholderText = ""
        Me.text8.SelectedText = ""
        Me.text8.ShadowDecoration.Parent = Me.text8
        Me.text8.Size = New System.Drawing.Size(469, 36)
        Me.text8.TabIndex = 6
        '
        'syntax9
        '
        Me.syntax9.Animated = True
        Me.syntax9.AutoCompleteCustomSource.AddRange(New String() {"txtaskconsole::", "openontext::", "webshow,render", "txtMsgAsk", "widLoadAskmsgweb"})
        Me.syntax9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.syntax9.BorderColor = System.Drawing.Color.Black
        Me.syntax9.BorderRadius = 10
        Me.syntax9.BorderThickness = 0
        Me.syntax9.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.syntax9.DefaultText = ""
        Me.syntax9.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.syntax9.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.syntax9.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax9.DisabledState.Parent = Me.syntax9
        Me.syntax9.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax9.FillColor = System.Drawing.Color.Black
        Me.syntax9.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax9.FocusedState.Parent = Me.syntax9
        Me.syntax9.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.syntax9.ForeColor = System.Drawing.Color.White
        Me.syntax9.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax9.HoverState.Parent = Me.syntax9
        Me.syntax9.Location = New System.Drawing.Point(12, 415)
        Me.syntax9.Name = "syntax9"
        Me.syntax9.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.syntax9.PlaceholderForeColor = System.Drawing.Color.Black
        Me.syntax9.PlaceholderText = ""
        Me.syntax9.SelectedText = ""
        Me.syntax9.ShadowDecoration.Parent = Me.syntax9
        Me.syntax9.Size = New System.Drawing.Size(603, 36)
        Me.syntax9.TabIndex = 6
        '
        'txt9
        '
        Me.txt9.Animated = True
        Me.txt9.BorderColor = System.Drawing.Color.Black
        Me.txt9.BorderRadius = 10
        Me.txt9.BorderThickness = 0
        Me.txt9.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt9.DefaultText = ""
        Me.txt9.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt9.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt9.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt9.DisabledState.Parent = Me.txt9
        Me.txt9.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt9.FillColor = System.Drawing.Color.Black
        Me.txt9.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt9.FocusedState.Parent = Me.txt9
        Me.txt9.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt9.ForeColor = System.Drawing.Color.White
        Me.txt9.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt9.HoverState.Parent = Me.txt9
        Me.txt9.Location = New System.Drawing.Point(621, 415)
        Me.txt9.Name = "txt9"
        Me.txt9.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt9.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txt9.PlaceholderText = ""
        Me.txt9.SelectedText = ""
        Me.txt9.ShadowDecoration.Parent = Me.txt9
        Me.txt9.Size = New System.Drawing.Size(469, 36)
        Me.txt9.TabIndex = 6
        '
        'syntax10
        '
        Me.syntax10.Animated = True
        Me.syntax10.AutoCompleteCustomSource.AddRange(New String() {"txtaskconsole::", "openontext::", "webshow,render", "txtMsgAsk", "widLoadAskmsgweb"})
        Me.syntax10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.syntax10.BorderColor = System.Drawing.Color.Black
        Me.syntax10.BorderRadius = 10
        Me.syntax10.BorderThickness = 0
        Me.syntax10.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.syntax10.DefaultText = ""
        Me.syntax10.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.syntax10.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.syntax10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax10.DisabledState.Parent = Me.syntax10
        Me.syntax10.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax10.FillColor = System.Drawing.Color.Black
        Me.syntax10.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax10.FocusedState.Parent = Me.syntax10
        Me.syntax10.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.syntax10.ForeColor = System.Drawing.Color.White
        Me.syntax10.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax10.HoverState.Parent = Me.syntax10
        Me.syntax10.Location = New System.Drawing.Point(12, 457)
        Me.syntax10.Name = "syntax10"
        Me.syntax10.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.syntax10.PlaceholderForeColor = System.Drawing.Color.Black
        Me.syntax10.PlaceholderText = ""
        Me.syntax10.SelectedText = ""
        Me.syntax10.ShadowDecoration.Parent = Me.syntax10
        Me.syntax10.Size = New System.Drawing.Size(603, 36)
        Me.syntax10.TabIndex = 6
        '
        'txt10
        '
        Me.txt10.Animated = True
        Me.txt10.BorderColor = System.Drawing.Color.Black
        Me.txt10.BorderRadius = 10
        Me.txt10.BorderThickness = 0
        Me.txt10.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt10.DefaultText = ""
        Me.txt10.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt10.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt10.DisabledState.Parent = Me.txt10
        Me.txt10.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt10.FillColor = System.Drawing.Color.Black
        Me.txt10.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt10.FocusedState.Parent = Me.txt10
        Me.txt10.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt10.ForeColor = System.Drawing.Color.White
        Me.txt10.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt10.HoverState.Parent = Me.txt10
        Me.txt10.Location = New System.Drawing.Point(621, 457)
        Me.txt10.Name = "txt10"
        Me.txt10.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt10.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txt10.PlaceholderText = ""
        Me.txt10.SelectedText = ""
        Me.txt10.ShadowDecoration.Parent = Me.txt10
        Me.txt10.Size = New System.Drawing.Size(469, 36)
        Me.txt10.TabIndex = 6
        '
        'syntax11
        '
        Me.syntax11.Animated = True
        Me.syntax11.AutoCompleteCustomSource.AddRange(New String() {"txtaskconsole::", "openontext::", "webshow,render", "txtMsgAsk", "widLoadAskmsgweb"})
        Me.syntax11.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.syntax11.BorderColor = System.Drawing.Color.Black
        Me.syntax11.BorderRadius = 10
        Me.syntax11.BorderThickness = 0
        Me.syntax11.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.syntax11.DefaultText = ""
        Me.syntax11.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.syntax11.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.syntax11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax11.DisabledState.Parent = Me.syntax11
        Me.syntax11.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax11.FillColor = System.Drawing.Color.Black
        Me.syntax11.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax11.FocusedState.Parent = Me.syntax11
        Me.syntax11.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.syntax11.ForeColor = System.Drawing.Color.White
        Me.syntax11.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax11.HoverState.Parent = Me.syntax11
        Me.syntax11.Location = New System.Drawing.Point(12, 499)
        Me.syntax11.Name = "syntax11"
        Me.syntax11.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.syntax11.PlaceholderForeColor = System.Drawing.Color.Black
        Me.syntax11.PlaceholderText = ""
        Me.syntax11.SelectedText = ""
        Me.syntax11.ShadowDecoration.Parent = Me.syntax11
        Me.syntax11.Size = New System.Drawing.Size(603, 36)
        Me.syntax11.TabIndex = 6
        '
        'txt11
        '
        Me.txt11.Animated = True
        Me.txt11.BorderColor = System.Drawing.Color.Black
        Me.txt11.BorderRadius = 10
        Me.txt11.BorderThickness = 0
        Me.txt11.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt11.DefaultText = ""
        Me.txt11.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt11.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt11.DisabledState.Parent = Me.txt11
        Me.txt11.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt11.FillColor = System.Drawing.Color.Black
        Me.txt11.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt11.FocusedState.Parent = Me.txt11
        Me.txt11.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt11.ForeColor = System.Drawing.Color.White
        Me.txt11.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt11.HoverState.Parent = Me.txt11
        Me.txt11.Location = New System.Drawing.Point(621, 499)
        Me.txt11.Name = "txt11"
        Me.txt11.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt11.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txt11.PlaceholderText = ""
        Me.txt11.SelectedText = ""
        Me.txt11.ShadowDecoration.Parent = Me.txt11
        Me.txt11.Size = New System.Drawing.Size(469, 36)
        Me.txt11.TabIndex = 6
        '
        'syntax12
        '
        Me.syntax12.Animated = True
        Me.syntax12.AutoCompleteCustomSource.AddRange(New String() {"txtaskconsole::", "openontext::", "webshow,render", "txtMsgAsk", "widLoadAskmsgweb"})
        Me.syntax12.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.syntax12.BorderColor = System.Drawing.Color.Black
        Me.syntax12.BorderRadius = 10
        Me.syntax12.BorderThickness = 0
        Me.syntax12.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.syntax12.DefaultText = ""
        Me.syntax12.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.syntax12.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.syntax12.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax12.DisabledState.Parent = Me.syntax12
        Me.syntax12.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.syntax12.FillColor = System.Drawing.Color.Black
        Me.syntax12.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax12.FocusedState.Parent = Me.syntax12
        Me.syntax12.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.syntax12.ForeColor = System.Drawing.Color.White
        Me.syntax12.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.syntax12.HoverState.Parent = Me.syntax12
        Me.syntax12.Location = New System.Drawing.Point(12, 541)
        Me.syntax12.Name = "syntax12"
        Me.syntax12.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.syntax12.PlaceholderForeColor = System.Drawing.Color.Black
        Me.syntax12.PlaceholderText = ""
        Me.syntax12.SelectedText = ""
        Me.syntax12.ShadowDecoration.Parent = Me.syntax12
        Me.syntax12.Size = New System.Drawing.Size(603, 36)
        Me.syntax12.TabIndex = 6
        '
        'txt12
        '
        Me.txt12.Animated = True
        Me.txt12.BorderColor = System.Drawing.Color.Black
        Me.txt12.BorderRadius = 10
        Me.txt12.BorderThickness = 0
        Me.txt12.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt12.DefaultText = ""
        Me.txt12.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt12.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt12.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt12.DisabledState.Parent = Me.txt12
        Me.txt12.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt12.FillColor = System.Drawing.Color.Black
        Me.txt12.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt12.FocusedState.Parent = Me.txt12
        Me.txt12.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt12.ForeColor = System.Drawing.Color.White
        Me.txt12.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt12.HoverState.Parent = Me.txt12
        Me.txt12.Location = New System.Drawing.Point(621, 541)
        Me.txt12.Name = "txt12"
        Me.txt12.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt12.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txt12.PlaceholderText = ""
        Me.txt12.SelectedText = ""
        Me.txt12.ShadowDecoration.Parent = Me.txt12
        Me.txt12.Size = New System.Drawing.Size(469, 36)
        Me.txt12.TabIndex = 6
        '
        'consoleapp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer), CType(CType(22, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1114, 595)
        Me.Controls.Add(Me.txt12)
        Me.Controls.Add(Me.syntax12)
        Me.Controls.Add(Me.txt11)
        Me.Controls.Add(Me.syntax11)
        Me.Controls.Add(Me.txt10)
        Me.Controls.Add(Me.syntax10)
        Me.Controls.Add(Me.txt9)
        Me.Controls.Add(Me.syntax9)
        Me.Controls.Add(Me.text8)
        Me.Controls.Add(Me.syntax8)
        Me.Controls.Add(Me.txt7)
        Me.Controls.Add(Me.syntax7)
        Me.Controls.Add(Me.txt6)
        Me.Controls.Add(Me.syntax6)
        Me.Controls.Add(Me.txt5)
        Me.Controls.Add(Me.syntax5)
        Me.Controls.Add(Me.txt4)
        Me.Controls.Add(Me.syntax4)
        Me.Controls.Add(Me.txt3)
        Me.Controls.Add(Me.syntax3)
        Me.Controls.Add(Me.txt2)
        Me.Controls.Add(Me.syntax2)
        Me.Controls.Add(Me.txt1)
        Me.Controls.Add(Me.syntax1)
        Me.Controls.Add(Me.Guna2Button2)
        Me.Controls.Add(Me.Guna2Button1)
        Me.Controls.Add(Me.GunaPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "consoleapp"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Console App - Poficol"
        Me.GunaPanel1.ResumeLayout(False)
        Me.GunaPanel1.PerformLayout()
        CType(Me.GunaPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GunaLabel1 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents GunaControlBox2 As Guna.UI.WinForms.GunaControlBox
    Friend WithEvents GunaControlBox1 As Guna.UI.WinForms.GunaControlBox
    Friend WithEvents GunaPanel1 As Guna.UI.WinForms.GunaPanel
    Friend WithEvents GunaPictureBox1 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents GunaElipse1 As Guna.UI.WinForms.GunaElipse
    Friend WithEvents Guna2ShadowForm1 As Guna.UI2.WinForms.Guna2ShadowForm
    Friend WithEvents Guna2DragControl1 As Guna.UI2.WinForms.Guna2DragControl
    Friend WithEvents Guna2DragControl2 As Guna.UI2.WinForms.Guna2DragControl
    Friend WithEvents Guna2DragControl3 As Guna.UI2.WinForms.Guna2DragControl
    Friend WithEvents Guna2Button2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents txt12 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents syntax12 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txt11 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents syntax11 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txt10 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents syntax10 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txt9 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents syntax9 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents text8 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents syntax8 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txt7 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents syntax7 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txt6 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents syntax6 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txt5 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents syntax5 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txt4 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents syntax4 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txt3 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents syntax3 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txt2 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents syntax2 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txt1 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents syntax1 As Guna.UI2.WinForms.Guna2TextBox
End Class
