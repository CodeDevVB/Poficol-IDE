﻿Public Class consoleapp
    Private Sub consoleapp_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class